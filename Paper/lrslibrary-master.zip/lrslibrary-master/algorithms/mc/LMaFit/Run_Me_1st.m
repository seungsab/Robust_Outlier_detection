mex -O -largeArrayDims updateSval.c -lmwblas -output  updateSval
mex -O -largeArrayDims partXY.c -lmwblas -output partXY