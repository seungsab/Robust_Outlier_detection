Direct Robust Matrix Factorization (DRMF) Matlab package

This package contains the code of DRMF, and a demo showing how to do video background extraction using DRMF.

Developed under Matlab 7.11.0.

To see how this package works, just run "demo_fgbg.m" directly.

Acknowledgement:
We thank Yi Ma et al (http://perception.csl.uiuc.edu/matrix-rank/sample_code.html) and Emmanuel Candes et al (http://www-stat.stanford.edu/~candes/svt/code.html) for generously publishing their code.

Contact: Liang Xiong (lxiong@cs.cmu.edu)
