% EALM (Lin et al. 2009)
% process_video('RPCA', 'EALM', 'dataset/demo.avi', 'output/demo_EALM.avi');
[L,S] = exact_alm_rpca(M);