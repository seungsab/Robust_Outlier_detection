% IALM + BLWS (Lin and Wei 2010)
% process_video('RPCA', 'IALM_BLWS', 'dataset/demo.avi', 'output/demo_IALM_BLWS.avi');
[L,S] = inexact_alm_rpca_with_blws(M);
