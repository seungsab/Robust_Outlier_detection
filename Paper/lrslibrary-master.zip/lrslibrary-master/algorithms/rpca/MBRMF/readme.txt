This is the demo code for:
Naiyan Wang, Dit-Yan Yeung. "Bayesian Robust Matrix Factorization for Image and Video Processing." ICCV2013
Project page: http://winsty.net/brmf.html

Usage:
0. Please run make.m the compile the necessary mex file.
1. Run the demo.m to reproduce the results in section 7.2 of original paper.
2. You can see three figures which correspond to PCP, BRMF, MBRMF

If you have any questions, please contact winsty@gmail.com