% IALM + LMSVDS (Liu et al. 2012)
% process_video('RPCA', 'IALM_LMSVDS', 'dataset/demo.avi', 'output/demo_IALM_LMSVDS.avi');
[L,S] = inexact_alm_rpca_with_lmsvds(M);
