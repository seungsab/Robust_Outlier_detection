addpath('..\FW_SPCP\func');
addpath('D:\solvers\PROPACK');
addpath('D:\solvers\cvx'); 
cvx_setup; warning off;
