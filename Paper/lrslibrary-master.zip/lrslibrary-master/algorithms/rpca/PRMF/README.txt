This is MATLAB implementation of paper "A Probabilistic Approach to Robust Matrix Factorization".
Only for demo Use. 
If you have questions about the code, please email: winsty@gmail.com