addpath(genpath(pwd));
GCO_BuildLib