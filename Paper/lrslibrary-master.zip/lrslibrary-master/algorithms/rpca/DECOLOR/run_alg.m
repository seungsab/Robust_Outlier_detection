% DECOLOR (Zhou et al. 2011)
% process_video('RPCA', 'DECOLOR', 'dataset/demo.avi', 'output/demo_DECOLOR.avi');
[L,S] = DECOLOR(M);
