% IALM (Lin et al. 2009)
% process_video('RPCA', 'IALM', 'dataset/demo.avi', 'output/demo_IALM.avi');
[L,S] = inexact_alm_rpca(M);