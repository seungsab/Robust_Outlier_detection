% ALM (Tang and Nehorai 2011)
% process_video('RPCA', 'ALM', 'dataset/demo.avi', 'output/demo_ALM.avi');
[L,S] = alm(M);
