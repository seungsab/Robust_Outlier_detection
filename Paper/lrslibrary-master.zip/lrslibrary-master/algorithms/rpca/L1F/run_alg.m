% L1 Filtering (Liu et al. 2011)
% process_video('RPCA', 'L1F', 'dataset/demo.avi', 'output/demo_L1F.avi');
[L,S] = rpca_l1f(M);